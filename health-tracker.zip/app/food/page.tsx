import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Plus, Search } from "lucide-react"

export default function FoodTrackingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-green-600" />
            <h1 className="text-xl font-bold">HealthTrack</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Dashboard
            </Link>
            <Link href="/food" className="text-sm font-medium text-green-600">
              Food
            </Link>
            <Link href="/exercise" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Exercise
            </Link>
            <Link href="/diet" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Diet Plans
            </Link>
            <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Profile
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Food Tracking</h2>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="mr-2 h-4 w-4" /> Add Food
            </Button>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            <div className="md:w-2/3 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Today's Meals</CardTitle>
                  <CardDescription>Track what you've eaten today</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="breakfast" className="space-y-4">
                    <TabsList className="grid grid-cols-4">
                      <TabsTrigger value="breakfast">Breakfast</TabsTrigger>
                      <TabsTrigger value="lunch">Lunch</TabsTrigger>
                      <TabsTrigger value="dinner">Dinner</TabsTrigger>
                      <TabsTrigger value="snacks">Snacks</TabsTrigger>
                    </TabsList>
                    <TabsContent value="breakfast">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-medium">Greek Yogurt with Berries</h4>
                            <p className="text-sm text-muted-foreground">200g - 180 calories</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-medium">Whole Grain Toast</h4>
                            <p className="text-sm text-muted-foreground">2 slices - 160 calories</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                        <Button variant="outline" className="w-full">
                          <Plus className="mr-2 h-4 w-4" /> Add Breakfast Item
                        </Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="lunch">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-medium">Grilled Chicken Salad</h4>
                            <p className="text-sm text-muted-foreground">350g - 320 calories</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                        <Button variant="outline" className="w-full">
                          <Plus className="mr-2 h-4 w-4" /> Add Lunch Item
                        </Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="dinner">
                      <div className="space-y-4">
                        <Button variant="outline" className="w-full">
                          <Plus className="mr-2 h-4 w-4" /> Add Dinner Item
                        </Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="snacks">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-medium">Apple</h4>
                            <p className="text-sm text-muted-foreground">1 medium - 95 calories</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                        <Button variant="outline" className="w-full">
                          <Plus className="mr-2 h-4 w-4" /> Add Snack
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Food Search</CardTitle>
                  <CardDescription>Find and add foods to your meals</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex w-full items-center space-x-2 mb-4">
                    <Input placeholder="Search for foods..." className="flex-1" />
                    <Button type="submit">
                      <Search className="h-4 w-4 mr-2" /> Search
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Recent searches:</p>
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm">
                        Chicken
                      </Button>
                      <Button variant="outline" size="sm">
                        Rice
                      </Button>
                      <Button variant="outline" size="sm">
                        Broccoli
                      </Button>
                      <Button variant="outline" size="sm">
                        Salmon
                      </Button>
                      <Button variant="outline" size="sm">
                        Oatmeal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="md:w-1/3 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Nutrition Summary</CardTitle>
                  <CardDescription>Today's nutritional intake</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Calories</span>
                        <span className="text-sm font-medium">755 / 2,200</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "34%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Protein</span>
                        <span className="text-sm font-medium">45g / 120g</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "38%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Carbs</span>
                        <span className="text-sm font-medium">85g / 250g</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "34%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Fat</span>
                        <span className="text-sm font-medium">25g / 70g</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-red-500 h-2.5 rounded-full" style={{ width: "36%" }}></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Meal Suggestions</CardTitle>
                  <CardDescription>Based on your remaining nutrients</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Grilled Salmon with Vegetables</h4>
                      <p className="text-sm text-muted-foreground">High in protein and healthy fats</p>
                      <Button variant="link" className="p-0 h-auto text-green-600">
                        Add to dinner
                      </Button>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Quinoa Bowl with Avocado</h4>
                      <p className="text-sm text-muted-foreground">Good source of complex carbs</p>
                      <Button variant="link" className="p-0 h-auto text-green-600">
                        Add to dinner
                      </Button>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h4 className="font-medium">Greek Yogurt with Nuts</h4>
                      <p className="text-sm text-muted-foreground">Protein-rich evening snack</p>
                      <Button variant="link" className="p-0 h-auto text-green-600">
                        Add to snacks
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline">
              Privacy
            </Link>
            <Link href="#" className="hover:underline">
              Terms
            </Link>
            <Link href="#" className="hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
