import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Plus, Dumbbell, Clock, Calendar } from "lucide-react"
import { ExerciseEntryForm } from "@/components/exercise-entry-form"
import { WorkoutHistory } from "@/components/workout-history"

export default function ExercisePage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-green-600" />
            <h1 className="text-xl font-bold">HealthTrack</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Dashboard
            </Link>
            <Link href="/food" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Food
            </Link>
            <Link href="/exercise" className="text-sm font-medium text-green-600">
              Exercise
            </Link>
            <Link href="/diet" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Diet Plans
            </Link>
            <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Profile
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Exercise Tracking</h2>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="mr-2 h-4 w-4" /> Log Workout
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Today's Activity</CardTitle>
                <Dumbbell className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">320 kcal</div>
                <p className="text-xs text-muted-foreground">45 min active today</p>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="rounded-lg bg-green-100 p-2">
                    <div className="font-medium">Steps</div>
                    <div>7,842</div>
                  </div>
                  <div className="rounded-lg bg-green-100 p-2">
                    <div className="font-medium">Distance</div>
                    <div>3.2 km</div>
                  </div>
                  <div className="rounded-lg bg-green-100 p-2">
                    <div className="font-medium">Active</div>
                    <div>45 min</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Weekly Goal</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3 / 5 workouts</div>
                <p className="text-xs text-muted-foreground">2 more to reach your goal</p>
                <div className="mt-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-medium">Progress</span>
                    <span className="text-xs font-medium">60%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "60%" }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Upcoming Workout</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">HIIT Training</div>
                <p className="text-xs text-muted-foreground">Tomorrow, 7:00 AM</p>
                <div className="mt-4 flex justify-between">
                  <Button variant="outline" size="sm">
                    Reschedule
                  </Button>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="log" className="space-y-4">
            <TabsList>
              <TabsTrigger value="log">Log Exercise</TabsTrigger>
              <TabsTrigger value="history">Workout History</TabsTrigger>
              <TabsTrigger value="stats">Statistics</TabsTrigger>
            </TabsList>
            <TabsContent value="log">
              <Card>
                <CardHeader>
                  <CardTitle>Log Your Workout</CardTitle>
                  <CardDescription>Record your exercise activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-medium mb-2">Quick Add</h3>
                        <div className="grid grid-cols-2 gap-2">
                          <Button variant="outline" className="justify-start">
                            <Dumbbell className="mr-2 h-4 w-4" /> Strength Training
                          </Button>
                          <Button variant="outline" className="justify-start">
                            <Activity className="mr-2 h-4 w-4" /> Running
                          </Button>
                          <Button variant="outline" className="justify-start">
                            <Activity className="mr-2 h-4 w-4" /> Cycling
                          </Button>
                          <Button variant="outline" className="justify-start">
                            <Activity className="mr-2 h-4 w-4" /> Swimming
                          </Button>
                          <Button variant="outline" className="justify-start">
                            <Activity className="mr-2 h-4 w-4" /> Yoga
                          </Button>
                          <Button variant="outline" className="justify-start">
                            <Plus className="mr-2 h-4 w-4" /> Custom
                          </Button>
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-medium mb-2">Recent Workouts</h3>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <h4 className="font-medium">Strength Training</h4>
                              <p className="text-xs text-muted-foreground">45 min · 320 kcal</p>
                            </div>
                            <Button variant="ghost" size="sm">
                              Log Again
                            </Button>
                          </div>
                          <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <h4 className="font-medium">Running</h4>
                              <p className="text-xs text-muted-foreground">30 min · 280 kcal</p>
                            </div>
                            <Button variant="ghost" size="sm">
                              Log Again
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-medium mb-2">Custom Exercise</h3>
                      <ExerciseEntryForm />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>Workout History</CardTitle>
                  <CardDescription>View your past workouts</CardDescription>
                </CardHeader>
                <CardContent>
                  <WorkoutHistory />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="stats">
              <Card>
                <CardHeader>
                  <CardTitle>Exercise Statistics</CardTitle>
                  <CardDescription>Your workout trends and progress</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">Exercise statistics chart will be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline">
              Privacy
            </Link>
            <Link href="#" className="hover:underline">
              Terms
            </Link>
            <Link href="#" className="hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
