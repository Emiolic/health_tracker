import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, Lightbulb, ChevronRight, Zap, BarChart } from "lucide-react"
import Link from "next/link"
import { AIChat } from "@/components/ai-chat"
import { Badge } from "@/components/ui/badge"

export default function AIPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 pb-20 md:pb-8">
        <div className="flex flex-col gap-8">
          <section className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
              <div className="flex items-center">
                <h2 className="text-3xl font-bold tracking-tight font-fredoka text-gray-900 flex items-center">
                  AI Health Coach
                  <img src="/placeholder.svg?height=24&width=24" alt="AI Coach Logo" className="ml-2 h-6 w-6" />
                </h2>
                <p className="text-muted-foreground font-poppins">Your personalized health assistant powered by AI</p>
              </div>
            </div>
          </section>

          <Card className="bg-gradient-to-r from-accent/10 to-accent/5 border-accent/20 overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="md:w-2/3">
                  <h3 className="text-xl font-bold mb-2 font-fredoka text-accent">Meet Your AI Health Coach</h3>
                  <p className="mb-4 text-gray-700">
                    Our AI-powered health coach analyzes your data to provide personalized recommendations, answer your
                    health questions, and help you achieve your wellness goals.
                  </p>
                </div>
                <div className="md:w-1/3 flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-accent/20 flex items-center justify-center pulse-animation">
                    <img src="/placeholder.svg?height=48&width=48" alt="AI Coach Logo" className="h-12 w-12" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="chat" className="space-y-4">
            <TabsList className="bg-muted/50 p-1">
              <TabsTrigger value="chat" className="data-[state=active]:bg-white data-[state=active]:text-accent">
                <MessageSquare className="h-4 w-4 mr-2" /> Chat
              </TabsTrigger>
              <TabsTrigger value="insights" className="data-[state=active]:bg-white data-[state=active]:text-accent">
                <Lightbulb className="h-4 w-4 mr-2" /> Insights
              </TabsTrigger>
              <TabsTrigger value="plans" className="data-[state=active]:bg-white data-[state=active]:text-accent">
                <BarChart className="h-4 w-4 mr-2" /> Plans
              </TabsTrigger>
            </TabsList>

            <TabsContent value="chat" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Chat with Your AI Coach</CardTitle>
                  <CardDescription>Ask questions about nutrition, fitness, or general health</CardDescription>
                </CardHeader>
                <CardContent className="h-[500px]">
                  <AIChat />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="insights" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">AI Health Insights</CardTitle>
                  <CardDescription>Personalized insights based on your health data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg bg-orange/5 border-orange/20">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-orange/20 flex items-center justify-center">
                          <Zap className="h-4 w-4 text-orange" />
                        </div>
                        <h3 className="font-medium font-poppins">Energy Optimization</h3>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">
                        Based on your sleep patterns and activity levels, your energy dips around 3 PM. Consider a
                        protein-rich snack and short walk at this time.
                      </p>
                      <div className="flex justify-end">
                        <Button variant="ghost" size="sm" className="text-orange hover:bg-orange/10">
                          Learn More <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg bg-primary/5 border-primary/20">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                          <Zap className="h-4 w-4 text-primary" />
                        </div>
                        <h3 className="font-medium font-poppins">Nutrition Pattern</h3>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">
                        You're consistently low on vitamin D and omega-3 fatty acids. Adding fatty fish like salmon
                        twice a week could help address this gap.
                      </p>
                      <div className="flex justify-end">
                        <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10">
                          Learn More <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg bg-teal/5 border-teal/20">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-teal/20 flex items-center justify-center">
                          <Zap className="h-4 w-4 text-teal" />
                        </div>
                        <h3 className="font-medium font-poppins">Workout Efficiency</h3>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">
                        Your strength training sessions show better results when done in the morning. Consider shifting
                        your workouts earlier for optimal muscle gain.
                      </p>
                      <div className="flex justify-end">
                        <Button variant="ghost" size="sm" className="text-teal hover:bg-teal/10">
                          Learn More <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="plans" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">AI-Generated Plans</CardTitle>
                  <CardDescription>Custom plans tailored to your goals and preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-accent p-4">
                        <div className="flex justify-between items-center">
                          <h3 className="font-medium text-white font-poppins">Weight Management Plan</h3>
                          <Badge className="bg-white text-accent">Recommended</Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-700 mb-4">
                          A balanced approach to help you reach your target weight through sustainable nutrition and
                          exercise habits.
                        </p>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-accent mr-2" />
                            Calorie-controlled meal plan
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-accent mr-2" />3 workouts per week (30-45 min)
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-accent mr-2" />
                            Weekly progress tracking
                          </li>
                        </ul>
                        <Button className="w-full bg-accent hover:bg-accent-dark">View Plan</Button>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-primary p-4">
                        <h3 className="font-medium text-white font-poppins">Strength Building Plan</h3>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-700 mb-4">
                          Focus on building lean muscle mass and increasing overall strength through progressive
                          resistance training.
                        </p>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-primary mr-2" />
                            High-protein nutrition plan
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-primary mr-2" />4 strength sessions per week
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-primary mr-2" />
                            Recovery optimization
                          </li>
                        </ul>
                        <Button className="w-full bg-primary hover:bg-primary-dark">View Plan</Button>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-teal p-4">
                        <h3 className="font-medium text-white font-poppins">Stress Management Plan</h3>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-700 mb-4">
                          Holistic approach to reducing stress through mindfulness, nutrition, and gentle exercise.
                        </p>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-teal mr-2" />
                            Anti-inflammatory diet plan
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-teal mr-2" />
                            Daily meditation practices
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-teal mr-2" />
                            Yoga and gentle movement
                          </li>
                        </ul>
                        <Button className="w-full bg-teal hover:bg-teal/80">View Plan</Button>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-orange p-4">
                        <h3 className="font-medium text-white font-poppins">Endurance Building Plan</h3>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-700 mb-4">
                          Improve cardiovascular fitness and stamina through progressive cardio training.
                        </p>
                        <ul className="space-y-2 mb-4">
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-orange mr-2" />
                            Carb-cycling nutrition plan
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-orange mr-2" />
                            Interval and steady-state cardio
                          </li>
                          <li className="flex items-center text-sm">
                            <ChevronRight className="h-4 w-4 text-orange mr-2" />
                            Heart rate zone training
                          </li>
                        </ul>
                        <Button className="w-full bg-orange hover:bg-orange/80">View Plan</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0 bg-white">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Privacy
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Terms
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
