import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Dumbbell, LineChart, TrendingUp, Droplet, Award } from "lucide-react"
import { HealthMetricsChart } from "@/components/health-metrics-chart"
import { RecentMeals } from "@/components/recent-meals"
import { DietRecommendations } from "@/components/diet-recommendations"
import { ExerciseLog } from "@/components/exercise-log"
import { HomeSlideshow } from "@/components/home-slideshow"
import Link from "next/link"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 pb-20 md:pb-8">
        <div className="flex flex-col gap-8">
          <section className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
              <div>
                <h2 className="text-3xl font-bold tracking-tight font-fredoka text-gray-900">Welcome back, Alex</h2>
                <p className="text-muted-foreground font-poppins">Your health journey is looking great today!</p>
              </div>
              <div className="flex items-center gap-2">
                <Button className="bg-primary hover:bg-primary-dark text-white">
                  <Activity className="mr-2 h-4 w-4" /> Track Now
                </Button>
                <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
                  <TrendingUp className="mr-2 h-4 w-4" /> View Progress
                </Button>
              </div>
            </div>

            {/* Add the slideshow component */}
            <HomeSlideshow />

            <div className="grid gap-4 md:grid-cols-3">
              <Card className="card-hover border-l-4 border-l-primary">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium font-poppins">Daily Calories</CardTitle>
                  <LineChart className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,850 / 2,200</div>
                  <p className="text-xs text-muted-foreground">350 calories remaining</p>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-full" style={{ width: "84%" }}></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-hover border-l-4 border-l-teal">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium font-poppins">Water Intake</CardTitle>
                  <Droplet className="h-4 w-4 text-teal" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1.2 / 2.5 L</div>
                  <p className="text-xs text-muted-foreground">1.3 L remaining</p>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-teal h-2.5 rounded-full" style={{ width: "48%" }}></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-hover border-l-4 border-l-orange">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium font-poppins">Exercise</CardTitle>
                  <Dumbbell className="h-4 w-4 text-orange" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">320 kcal</div>
                  <p className="text-xs text-muted-foreground">45 min active today</p>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-orange h-2.5 rounded-full" style={{ width: "65%" }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          <section>
            <Card className="bg-gradient-to-r from-accent to-accent-dark text-white overflow-hidden">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <div className="md:w-2/3">
                    <h3 className="text-xl font-bold mb-2 font-fredoka">Try Our AI Health Coach</h3>
                    <p className="mb-4 text-white/90">
                      Get personalized recommendations, meal plans, and workout routines tailored just for you.
                    </p>
                    <Link href="/ai">
                      <Button className="bg-white text-accent hover:bg-white/90">
                        <img src="/placeholder.svg?height=16&width=16" alt="AI Coach" className="mr-2 h-4 w-4" />
                        Get Started
                      </Button>
                    </Link>
                  </div>
                  <div className="md:w-1/3 flex justify-center">
                    <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center pulse-animation">
                      <img src="/placeholder.svg?height=48&width=48" alt="AI Coach Logo" className="h-12 w-12" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="bg-muted/50 p-1">
              <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Overview
              </TabsTrigger>
              <TabsTrigger value="food" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Food
              </TabsTrigger>
              <TabsTrigger value="exercise" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Exercise
              </TabsTrigger>
              <TabsTrigger value="diet" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Diet Recommendations
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Health Metrics</CardTitle>
                  <CardDescription>Your health trends over the past week</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <HealthMetricsChart />
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="font-fredoka text-gray-900">Weekly Goals</CardTitle>
                    <CardDescription>Your progress this week</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Exercise (3/5 days)</span>
                          <span className="text-sm font-medium">60%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-primary h-2.5 rounded-full" style={{ width: "60%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Water Intake (avg.)</span>
                          <span className="text-sm font-medium">75%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-teal h-2.5 rounded-full" style={{ width: "75%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Calorie Target</span>
                          <span className="text-sm font-medium">90%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-orange h-2.5 rounded-full" style={{ width: "90%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Protein Goal</span>
                          <span className="text-sm font-medium">65%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-accent h-2.5 rounded-full" style={{ width: "65%" }}></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="font-fredoka text-gray-900">Achievements</CardTitle>
                    <CardDescription>Your recent milestones</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 p-3 bg-primary/10 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                          <Award className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Workout Streak</p>
                          <p className="text-sm text-muted-foreground">Completed 5 days in a row</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 p-3 bg-teal/10 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-teal/20 flex items-center justify-center">
                          <Droplet className="h-5 w-5 text-teal" />
                        </div>
                        <div>
                          <p className="font-medium">Hydration Master</p>
                          <p className="text-sm text-muted-foreground">Met water goal 10 days this month</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 p-3 bg-orange/10 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-orange/20 flex items-center justify-center">
                          <Activity className="h-5 w-5 text-orange" />
                        </div>
                        <div>
                          <p className="font-medium">Step Champion</p>
                          <p className="text-sm text-muted-foreground">Reached 10,000 steps for 7 days</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="food" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Recent Meals</CardTitle>
                  <CardDescription>Your food intake for today</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentMeals />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="exercise" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Exercise Log</CardTitle>
                  <CardDescription>Your recent workouts</CardDescription>
                </CardHeader>
                <CardContent>
                  <ExerciseLog />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="diet" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Personalized Diet Recommendations</CardTitle>
                  <CardDescription>Based on your health goals and activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <DietRecommendations />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0 bg-white">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Privacy
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Terms
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
