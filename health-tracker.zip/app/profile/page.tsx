import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Bell, Lock, Save, User, Plus } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

export default function ProfilePage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-green-600" />
            <h1 className="text-xl font-bold">HealthTrack</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Dashboard
            </Link>
            <Link href="/food" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Food
            </Link>
            <Link href="/exercise" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Exercise
            </Link>
            <Link href="/diet" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Diet Plans
            </Link>
            <Link href="/profile" className="text-sm font-medium text-green-600">
              Profile
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Profile Settings</h2>
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center space-y-4">
                    <div className="relative">
                      <div className="h-24 w-24 rounded-full bg-green-100 flex items-center justify-center">
                        <User className="h-12 w-12 text-green-600" />
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="absolute bottom-0 right-0 rounded-full h-8 w-8 p-0"
                      >
                        <span className="sr-only">Change avatar</span>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="text-center">
                      <h3 className="text-lg font-medium">Alex Johnson</h3>
                      <p className="text-sm text-muted-foreground">alex.johnson@example.com</p>
                    </div>
                    <Separator />
                    <nav className="w-full">
                      <div className="space-y-1 w-full">
                        <Button variant="ghost" className="w-full justify-start">
                          <User className="mr-2 h-4 w-4" /> Personal Info
                        </Button>
                        <Button variant="ghost" className="w-full justify-start">
                          <Lock className="mr-2 h-4 w-4" /> Security
                        </Button>
                        <Button variant="ghost" className="w-full justify-start">
                          <Bell className="mr-2 h-4 w-4" /> Notifications
                        </Button>
                      </div>
                    </nav>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="md:w-3/4">
              <Tabs defaultValue="personal" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="personal">Personal Info</TabsTrigger>
                  <TabsTrigger value="health">Health Data</TabsTrigger>
                  <TabsTrigger value="goals">Goals</TabsTrigger>
                  <TabsTrigger value="preferences">Preferences</TabsTrigger>
                </TabsList>
                <TabsContent value="personal">
                  <Card>
                    <CardHeader>
                      <CardTitle>Personal Information</CardTitle>
                      <CardDescription>Update your personal details</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="first-name">First Name</Label>
                          <Input id="first-name" defaultValue="Alex" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="last-name">Last Name</Label>
                          <Input id="last-name" defaultValue="Johnson" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" type="email" defaultValue="alex.johnson@example.com" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input id="phone" type="tel" defaultValue="+1 (555) 123-4567" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="dob">Date of Birth</Label>
                          <Input id="dob" type="date" defaultValue="1990-05-15" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="gender">Gender</Label>
                          <Select defaultValue="male">
                            <SelectTrigger id="gender">
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="female">Female</SelectItem>
                              <SelectItem value="non-binary">Non-binary</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                              <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <Button className="bg-green-600 hover:bg-green-700">
                          <Save className="mr-2 h-4 w-4" /> Save Changes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="health">
                  <Card>
                    <CardHeader>
                      <CardTitle>Health Information</CardTitle>
                      <CardDescription>Update your health metrics</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="height">Height (cm)</Label>
                          <Input id="height" type="number" defaultValue="175" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weight">Weight (kg)</Label>
                          <Input id="weight" type="number" defaultValue="70" />
                        </div>
                        <div className="space-y-2"></div>
                        <div className="space-y-2">
                          <Label htmlFor="activity-level">Activity Level</Label>
                          <Select defaultValue="moderate">
                            <SelectTrigger id="activity-level">
                              <SelectValue placeholder="Select activity level" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sedentary">Sedentary</SelectItem>
                              <SelectItem value="light">Lightly Active</SelectItem>
                              <SelectItem value="moderate">Moderately Active</SelectItem>
                              <SelectItem value="very">Very Active</SelectItem>
                              <SelectItem value="extremely">Extremely Active</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="blood-type">Blood Type</Label>
                          <Select defaultValue="a-positive">
                            <SelectTrigger id="blood-type">
                              <SelectValue placeholder="Select blood type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="a-positive">A+</SelectItem>
                              <SelectItem value="a-negative">A-</SelectItem>
                              <SelectItem value="b-positive">B+</SelectItem>
                              <SelectItem value="b-negative">B-</SelectItem>
                              <SelectItem value="ab-positive">AB+</SelectItem>
                              <SelectItem value="ab-negative">AB-</SelectItem>
                              <SelectItem value="o-positive">O+</SelectItem>
                              <SelectItem value="o-negative">O-</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <Button className="bg-green-600 hover:bg-green-700">
                          <Save className="mr-2 h-4 w-4" /> Save Changes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="goals">
                  <Card>
                    <CardHeader>
                      <CardTitle>Health Goals</CardTitle>
                      <CardDescription>Set your health and fitness goals</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="weight-goal">Weight Goal</Label>
                          <Select defaultValue="maintain">
                            <SelectTrigger id="weight-goal">
                              <SelectValue placeholder="Select weight goal" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="lose">Lose Weight</SelectItem>
                              <SelectItem value="maintain">Maintain Weight</SelectItem>
                              <SelectItem value="gain">Gain Weight</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="target-weight">Target Weight (kg)</Label>
                          <Input id="target-weight" type="number" defaultValue="68" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weekly-exercise">Weekly Exercise Goal (days)</Label>
                          <Select defaultValue="5">
                            <SelectTrigger id="weekly-exercise">
                              <SelectValue placeholder="Select days per week" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">1 day</SelectItem>
                              <SelectItem value="2">2 days</SelectItem>
                              <SelectItem value="3">3 days</SelectItem>
                              <SelectItem value="4">4 days</SelectItem>
                              <SelectItem value="5">5 days</SelectItem>
                              <SelectItem value="6">6 days</SelectItem>
                              <SelectItem value="7">7 days</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="daily-water">Daily Water Intake Goal (L)</Label>
                          <Input id="daily-water" type="number" defaultValue="2.5" step="0.1" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="daily-calories">Daily Calorie Goal</Label>
                          <Input id="daily-calories" type="number" defaultValue="2200" />
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <Button className="bg-green-600 hover:bg-green-700">
                          <Save className="mr-2 h-4 w-4" /> Save Changes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="preferences">
                  <Card>
                    <CardHeader>
                      <CardTitle>App Preferences</CardTitle>
                      <CardDescription>Customize your app experience</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Notifications</h3>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="meal-reminders" className="flex-1">
                              Meal Reminders
                            </Label>
                            <Switch id="meal-reminders" defaultChecked />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label htmlFor="workout-reminders" className="flex-1">
                              Workout Reminders
                            </Label>
                            <Switch id="workout-reminders" defaultChecked />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label htmlFor="water-reminders" className="flex-1">
                              Water Intake Reminders
                            </Label>
                            <Switch id="water-reminders" defaultChecked />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label htmlFor="progress-updates" className="flex-1">
                              Weekly Progress Updates
                            </Label>
                            <Switch id="progress-updates" defaultChecked />
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Units</h3>
                        <div className="space-y-2">
                          <div className="space-y-2">
                            <Label htmlFor="weight-unit">Weight Unit</Label>
                            <Select defaultValue="kg">
                              <SelectTrigger id="weight-unit">
                                <SelectValue placeholder="Select weight unit" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="kg">Kilograms (kg)</SelectItem>
                                <SelectItem value="lb">Pounds (lb)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="height-unit">Height Unit</Label>
                            <Select defaultValue="cm">
                              <SelectTrigger id="height-unit">
                                <SelectValue placeholder="Select height unit" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="cm">Centimeters (cm)</SelectItem>
                                <SelectItem value="ft">Feet/Inches (ft/in)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Theme</h3>
                        <div className="space-y-2">
                          <Label htmlFor="theme">App Theme</Label>
                          <Select defaultValue="light">
                            <SelectTrigger id="theme">
                              <SelectValue placeholder="Select theme" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="light">Light</SelectItem>
                              <SelectItem value="dark">Dark</SelectItem>
                              <SelectItem value="system">System Default</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button className="bg-green-600 hover:bg-green-700">
                          <Save Preferences className="mr-2 h-4 w-4" /> Save
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline">
              Privacy
            </Link>
            <Link href="#" className="hover:underline">
              Terms
            </Link>
            <Link href="#" className="hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
