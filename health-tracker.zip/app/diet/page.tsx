import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Apple, Filter, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function DietRecommendationsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-white">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-green-600" />
            <h1 className="text-xl font-bold">HealthTrack</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Dashboard
            </Link>
            <Link href="/food" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Food
            </Link>
            <Link href="/exercise" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Exercise
            </Link>
            <Link href="/diet" className="text-sm font-medium text-green-600">
              Diet Plans
            </Link>
            <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-green-600">
              Profile
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Diet Recommendations</h2>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" /> Filter Options
            </Button>
          </div>

          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-green-600" />
                Personalized Recommendations
              </CardTitle>
              <CardDescription>Based on your health profile, activity level, and nutritional needs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-white p-4 rounded-lg">
                <p className="mb-4">Your recommended daily intake:</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="bg-green-100 p-3 rounded-lg text-center">
                    <p className="text-sm text-muted-foreground">Calories</p>
                    <p className="text-xl font-bold">2,200</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-lg text-center">
                    <p className="text-sm text-muted-foreground">Protein</p>
                    <p className="text-xl font-bold">120g</p>
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-lg text-center">
                    <p className="text-sm text-muted-foreground">Carbs</p>
                    <p className="text-xl font-bold">250g</p>
                  </div>
                  <div className="bg-red-100 p-3 rounded-lg text-center">
                    <p className="text-sm text-muted-foreground">Fat</p>
                    <p className="text-xl font-bold">70g</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  These recommendations are based on your goal to maintain weight with moderate activity level.
                  <Button variant="link" className="p-0 h-auto text-green-600">
                    Adjust your goals
                  </Button>
                </p>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="meal-plans" className="space-y-4">
            <TabsList>
              <TabsTrigger value="meal-plans">Meal Plans</TabsTrigger>
              <TabsTrigger value="recipes">Recipes</TabsTrigger>
              <TabsTrigger value="food-suggestions">Food Suggestions</TabsTrigger>
            </TabsList>
            <TabsContent value="meal-plans">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>Balanced Diet</CardTitle>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <CardDescription>Well-balanced nutrition for overall health</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Key Benefits:</h4>
                        <ul className="text-sm space-y-1">
                          <li>• Balanced macronutrients</li>
                          <li>• Rich in essential vitamins and minerals</li>
                          <li>• Supports overall health and energy</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Sample Day:</h4>
                        <div className="text-sm space-y-2">
                          <div>
                            <p className="font-medium">Breakfast:</p>
                            <p className="text-muted-foreground">Oatmeal with berries and nuts</p>
                          </div>
                          <div>
                            <p className="font-medium">Lunch:</p>
                            <p className="text-muted-foreground">Grilled chicken salad with olive oil dressing</p>
                          </div>
                          <div>
                            <p className="font-medium">Dinner:</p>
                            <p className="text-muted-foreground">Baked salmon with quinoa and roasted vegetables</p>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full bg-green-600 hover:bg-green-700">View Full Plan</Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>High Protein</CardTitle>
                    <CardDescription>Ideal for muscle building and recovery</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Key Benefits:</h4>
                        <ul className="text-sm space-y-1">
                          <li>• Supports muscle growth and repair</li>
                          <li>• Enhances workout recovery</li>
                          <li>• Promotes satiety and weight management</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Sample Day:</h4>
                        <div className="text-sm space-y-2">
                          <div>
                            <p className="font-medium">Breakfast:</p>
                            <p className="text-muted-foreground">Protein smoothie with Greek yogurt</p>
                          </div>
                          <div>
                            <p className="font-medium">Lunch:</p>
                            <p className="text-muted-foreground">Turkey and avocado wrap with cottage cheese</p>
                          </div>
                          <div>
                            <p className="font-medium">Dinner:</p>
                            <p className="text-muted-foreground">Steak with sweet potato and green beans</p>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full">View Full Plan</Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Mediterranean</CardTitle>
                    <CardDescription>Heart-healthy diet with proven benefits</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Key Benefits:</h4>
                        <ul className="text-sm space-y-1">
                          <li>• Supports heart health</li>
                          <li>• Rich in antioxidants</li>
                          <li>• May reduce inflammation</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Sample Day:</h4>
                        <div className="text-sm space-y-2">
                          <div>
                            <p className="font-medium">Breakfast:</p>
                            <p className="text-muted-foreground">Greek yogurt with honey and walnuts</p>
                          </div>
                          <div>
                            <p className="font-medium">Lunch:</p>
                            <p className="text-muted-foreground">Mediterranean salad with feta and olive oil</p>
                          </div>
                          <div>
                            <p className="font-medium">Dinner:</p>
                            <p className="text-muted-foreground">Grilled fish with roasted vegetables and hummus</p>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full">View Full Plan</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="recipes">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold">Recommended Recipes</h3>
                  <Button variant="outline">View All Recipes</Button>
                </div>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                      <img
                        src="/placeholder.svg?height=200&width=400"
                        alt="Grilled Salmon with Avocado Salsa"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle>Grilled Salmon with Avocado Salsa</CardTitle>
                      <CardDescription>High protein, omega-3 rich dinner</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between mb-4">
                        <div className="text-sm">
                          <p className="font-medium">Calories</p>
                          <p>420</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Protein</p>
                          <p>38g</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Time</p>
                          <p>25 min</p>
                        </div>
                      </div>
                      <Button className="w-full">View Recipe</Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                      <img
                        src="/placeholder.svg?height=200&width=400"
                        alt="Quinoa Buddha Bowl"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle>Quinoa Buddha Bowl</CardTitle>
                      <CardDescription>Nutrient-dense vegetarian meal</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between mb-4">
                        <div className="text-sm">
                          <p className="font-medium">Calories</p>
                          <p>380</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Protein</p>
                          <p>14g</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Time</p>
                          <p>20 min</p>
                        </div>
                      </div>
                      <Button className="w-full">View Recipe</Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                      <img
                        src="/placeholder.svg?height=200&width=400"
                        alt="Greek Yogurt Parfait"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle>Greek Yogurt Parfait</CardTitle>
                      <CardDescription>Protein-rich breakfast or snack</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between mb-4">
                        <div className="text-sm">
                          <p className="font-medium">Calories</p>
                          <p>280</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Protein</p>
                          <p>18g</p>
                        </div>
                        <div className="text-sm">
                          <p className="font-medium">Time</p>
                          <p>5 min</p>
                        </div>
                      </div>
                      <Button className="w-full">View Recipe</Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="food-suggestions">
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Foods</CardTitle>
                  <CardDescription>Foods that align with your nutritional needs</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-3">Protein Sources</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-blue-600" />
                          </div>
                          <p className="font-medium text-sm">Chicken Breast</p>
                          <p className="text-xs text-muted-foreground">31g per 100g</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-blue-600" />
                          </div>
                          <p className="font-medium text-sm">Greek Yogurt</p>
                          <p className="text-xs text-muted-foreground">10g per 100g</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-blue-600" />
                          </div>
                          <p className="font-medium text-sm">Salmon</p>
                          <p className="text-xs text-muted-foreground">25g per 100g</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-blue-600" />
                          </div>
                          <p className="font-medium text-sm">Lentils</p>
                          <p className="text-xs text-muted-foreground">9g per 100g</p>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Complex Carbohydrates</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-yellow-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-yellow-600" />
                          </div>
                          <p className="font-medium text-sm">Sweet Potato</p>
                          <p className="text-xs text-muted-foreground">High in fiber</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-yellow-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-yellow-600" />
                          </div>
                          <p className="font-medium text-sm">Quinoa</p>
                          <p className="text-xs text-muted-foreground">Complete protein</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-yellow-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-yellow-600" />
                          </div>
                          <p className="font-medium text-sm">Brown Rice</p>
                          <p className="text-xs text-muted-foreground">Rich in minerals</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-yellow-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-yellow-600" />
                          </div>
                          <p className="font-medium text-sm">Oats</p>
                          <p className="text-xs text-muted-foreground">Heart healthy</p>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-3">Healthy Fats</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-red-600" />
                          </div>
                          <p className="font-medium text-sm">Avocado</p>
                          <p className="text-xs text-muted-foreground">Monounsaturated</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-red-600" />
                          </div>
                          <p className="font-medium text-sm">Olive Oil</p>
                          <p className="text-xs text-muted-foreground">Heart healthy</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-red-600" />
                          </div>
                          <p className="font-medium text-sm">Walnuts</p>
                          <p className="text-xs text-muted-foreground">Omega-3 rich</p>
                        </div>
                        <div className="flex flex-col items-center p-3 border rounded-lg">
                          <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full mb-2">
                            <Apple className="h-6 w-6 text-red-600" />
                          </div>
                          <p className="font-medium text-sm">Chia Seeds</p>
                          <p className="text-xs text-muted-foreground">Fiber rich</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline">
              Privacy
            </Link>
            <Link href="#" className="hover:underline">
              Terms
            </Link>
            <Link href="#" className="hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
