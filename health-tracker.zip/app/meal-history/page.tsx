import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, ChevronLeft, ChevronRight, Filter, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { MealHistory } from "@/components/meal-history"
import Link from "next/link"

export default function MealHistoryPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 pb-20 md:pb-8">
        <div className="flex flex-col gap-8">
          <section className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
              <div>
                <h2 className="text-3xl font-bold tracking-tight font-fredoka text-gray-900">Meal History</h2>
                <p className="text-muted-foreground font-poppins">Track and analyze your eating patterns</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 md:w-64">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Search meals..." className="pl-9" />
                </div>
                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" /> Filter
                </Button>
              </div>
            </div>
          </section>

          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" className="gap-1">
              <ChevronLeft className="h-4 w-4" /> Previous
            </Button>
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              <span className="font-medium">April 10 - April 16, 2025</span>
            </div>
            <Button variant="outline" size="sm" className="gap-1">
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <Tabs defaultValue="all" className="space-y-4">
            <TabsList className="bg-muted/50 p-1">
              <TabsTrigger value="all" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                All Meals
              </TabsTrigger>
              <TabsTrigger value="breakfast" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Breakfast
              </TabsTrigger>
              <TabsTrigger value="lunch" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Lunch
              </TabsTrigger>
              <TabsTrigger value="dinner" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Dinner
              </TabsTrigger>
              <TabsTrigger value="snacks" className="data-[state=active]:bg-white data-[state=active]:text-primary">
                Snacks
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">All Meals</CardTitle>
                  <CardDescription>Your complete meal history</CardDescription>
                </CardHeader>
                <CardContent>
                  <MealHistory />
                </CardContent>
              </Card>

              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Nutrition Summary</CardTitle>
                  <CardDescription>Average daily intake for this period</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-4">
                    <div className="p-4 bg-primary/10 rounded-lg text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calories</p>
                      <p className="text-2xl font-bold text-primary">1,950</p>
                      <p className="text-xs text-muted-foreground">Daily avg.</p>
                    </div>
                    <div className="p-4 bg-accent/10 rounded-lg text-center">
                      <p className="text-sm text-muted-foreground mb-1">Protein</p>
                      <p className="text-2xl font-bold text-accent">95g</p>
                      <p className="text-xs text-muted-foreground">Daily avg.</p>
                    </div>
                    <div className="p-4 bg-orange/10 rounded-lg text-center">
                      <p className="text-sm text-muted-foreground mb-1">Carbs</p>
                      <p className="text-2xl font-bold text-orange">220g</p>
                      <p className="text-xs text-muted-foreground">Daily avg.</p>
                    </div>
                    <div className="p-4 bg-teal/10 rounded-lg text-center">
                      <p className="text-sm text-muted-foreground mb-1">Fat</p>
                      <p className="text-2xl font-bold text-teal">65g</p>
                      <p className="text-xs text-muted-foreground">Daily avg.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="breakfast" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Breakfast History</CardTitle>
                  <CardDescription>Your breakfast meals</CardDescription>
                </CardHeader>
                <CardContent>
                  <MealHistory mealType="Breakfast" />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="lunch" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Lunch History</CardTitle>
                  <CardDescription>Your lunch meals</CardDescription>
                </CardHeader>
                <CardContent>
                  <MealHistory mealType="Lunch" />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="dinner" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Dinner History</CardTitle>
                  <CardDescription>Your dinner meals</CardDescription>
                </CardHeader>
                <CardContent>
                  <MealHistory mealType="Dinner" />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="snacks" className="space-y-4">
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="font-fredoka text-gray-900">Snacks History</CardTitle>
                  <CardDescription>Your snack meals</CardDescription>
                </CardHeader>
                <CardContent>
                  <MealHistory mealType="Snack" />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0 bg-white">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">&copy; 2025 HealthTrack. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Privacy
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Terms
            </Link>
            <Link href="#" className="hover:underline hover:text-primary transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
