"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"

const slides = [
  {
    id: 1,
    title: "Healthy Nigerian Recipes",
    description: "Discover nutritious twists on traditional Nigerian dishes",
    image: "/placeholder.svg?height=400&width=800",
    color: "from-primary/40 to-primary/10",
    url: "/blog/nigerian-recipes",
  },
  {
    id: 2,
    title: "Fitness Tips for Busy Professionals",
    description: "Quick workouts that fit into your hectic schedule",
    image: "/placeholder.svg?height=400&width=800",
    color: "from-orange/40 to-orange/10",
    url: "/blog/fitness-tips",
  },
  {
    id: 3,
    title: "Mental Wellness Practices",
    description: "Simple daily habits to improve your mental health",
    image: "/placeholder.svg?height=400&width=800",
    color: "from-accent/40 to-accent/10",
    url: "/blog/mental-wellness",
  },
]

export function HomeSlideshow() {
  const [current, setCurrent] = useState(0)

  const nextSlide = () => {
    setCurrent(current === slides.length - 1 ? 0 : current + 1)
  }

  const prevSlide = () => {
    setCurrent(current === 0 ? slides.length - 1 : current - 1)
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)
    return () => clearInterval(interval)
  }, [current])

  return (
    <div className="relative w-full h-[300px] md:h-[400px] overflow-hidden rounded-xl">
      <div className="absolute inset-0 z-10 flex items-center justify-between p-4">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 rounded-full bg-black/20 text-white backdrop-blur-sm hover:bg-black/30"
          onClick={prevSlide}
        >
          <ChevronLeft className="h-6 w-6" />
          <span className="sr-only">Previous slide</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 rounded-full bg-black/20 text-white backdrop-blur-sm hover:bg-black/30"
          onClick={nextSlide}
        >
          <ChevronRight className="h-6 w-6" />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>

      <div className="absolute bottom-4 left-0 right-0 z-10 flex justify-center space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full ${
              index === current ? "bg-white" : "bg-white/50"
            } transition-all duration-300`}
            onClick={() => setCurrent(index)}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          <div className={`absolute inset-0 bg-gradient-to-r ${slides[current].color}`} />
          <img
            src={slides[current].image || "/placeholder.svg"}
            alt={slides[current].title}
            className="h-full w-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
            <h3 className="text-2xl font-bold font-fredoka mb-2">{slides[current].title}</h3>
            <p className="mb-4 max-w-md">{slides[current].description}</p>
            <Link href={slides[current].url}>
              <Button className="bg-white text-gray-900 hover:bg-white/90">Read More</Button>
            </Link>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
