"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Apple, Check } from "lucide-react"
import { motion } from "framer-motion"

export function DietRecommendations() {
  return (
    <Tabs defaultValue="today">
      <TabsList className="mb-4 bg-muted/50">
        <TabsTrigger value="today" className="data-[state=active]:bg-white data-[state=active]:text-primary">
          Today
        </TabsTrigger>
        <TabsTrigger value="week" className="data-[state=active]:bg-white data-[state=active]:text-primary">
          This Week
        </TabsTrigger>
        <TabsTrigger value="custom" className="data-[state=active]:bg-white data-[state=active]:text-primary">
          Custom Plan
        </TabsTrigger>
      </TabsList>
      <TabsContent value="today">
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {["Breakfast", "Lunch", "Dinner"].map((meal, index) => (
              <motion.div
                key={meal}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="card-hover border-t-4 border-t-primary">
                  <CardContent className="p-4">
                    <div className="flex flex-col items-center text-center space-y-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Apple className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-medium font-poppins">{meal}</h3>
                      <p className="text-sm text-muted-foreground">
                        {meal === "Breakfast"
                          ? "8:00 AM - 9:00 AM"
                          : meal === "Lunch"
                            ? "12:30 PM - 1:30 PM"
                            : "7:00 PM - 8:00 PM"}
                      </p>
                      <div className="w-full p-3 bg-primary/5 rounded-lg mt-2">
                        <p className="font-medium text-sm">
                          {meal === "Breakfast"
                            ? "Oatmeal with Berries"
                            : meal === "Lunch"
                              ? "Grilled Chicken Salad"
                              : "Baked Salmon with Quinoa"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {meal === "Breakfast" ? "350 calories" : meal === "Lunch" ? "450 calories" : "520 calories"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-medium mb-3 font-poppins">Snack Suggestions</h3>
            <div className="grid gap-4 md:grid-cols-2">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center p-3 border rounded-lg hover:border-teal transition-colors">
                  <div className="p-2 bg-teal/10 rounded-full mr-3">
                    <Apple className="h-5 w-5 text-teal" />
                  </div>
                  <div>
                    <p className="font-medium font-poppins">Greek Yogurt with Honey</p>
                    <p className="text-xs text-muted-foreground">180 calories - High protein</p>
                  </div>
                  <Badge className="ml-auto" variant="outline">
                    Morning
                  </Badge>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                <div className="flex items-center p-3 border rounded-lg hover:border-teal transition-colors">
                  <div className="p-2 bg-teal/10 rounded-full mr-3">
                    <Apple className="h-5 w-5 text-teal" />
                  </div>
                  <div>
                    <p className="font-medium font-poppins">Apple with Almond Butter</p>
                    <p className="text-xs text-muted-foreground">200 calories - Balanced</p>
                  </div>
                  <Badge className="ml-auto" variant="outline">
                    Afternoon
                  </Badge>
                </div>
              </motion.div>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-medium mb-3 font-poppins">Hydration Reminder</h3>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <div className="p-4 bg-teal/10 rounded-lg">
                <p>Remember to drink at least 2.5L of water today. You've had 1.2L so far.</p>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div className="bg-teal h-2.5 rounded-full" style={{ width: "48%" }}></div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </TabsContent>
      <TabsContent value="week">
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="card-hover">
              <CardContent className="p-4">
                <h3 className="font-medium mb-2 font-poppins">Weekly Meal Plan</h3>
                <p className="text-sm text-muted-foreground mb-4">Balanced nutrition for your goals</p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <Check className="h-4 w-4 text-primary mr-2" />
                    <span className="text-sm">Focus on lean proteins and complex carbs</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 text-primary mr-2" />
                    <span className="text-sm">Include at least 5 servings of vegetables daily</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 text-primary mr-2" />
                    <span className="text-sm">Limit processed foods and added sugars</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 text-primary mr-2" />
                    <span className="text-sm">Stay hydrated with 2.5L water daily</span>
                  </li>
                </ul>
                <Button className="w-full mt-4 bg-primary hover:bg-primary-dark">View Detailed Plan</Button>
              </CardContent>
            </Card>
            <Card className="card-hover">
              <CardContent className="p-4">
                <h3 className="font-medium mb-2 font-poppins">Nutritional Focus</h3>
                <p className="text-sm text-muted-foreground mb-4">Areas to improve this week</p>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Protein Intake</span>
                      <span className="text-sm font-medium">75%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Fiber Intake</span>
                      <span className="text-sm font-medium">60%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-orange h-2.5 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Omega-3 Fatty Acids</span>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-coral h-2.5 rounded-full" style={{ width: "45%" }}></div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-orange/10 border border-orange/20 rounded-lg">
                  <p className="text-sm">
                    Try to include more fatty fish, flaxseeds, and walnuts to increase your omega-3 intake.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </TabsContent>
      <TabsContent value="custom">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center justify-center p-8 border-2 border-dashed rounded-lg">
            <div className="text-center">
              <h3 className="font-medium mb-2 font-poppins">Create Custom Diet Plan</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Tailor a diet plan to your specific needs and preferences
              </p>
              <Button className="bg-primary hover:bg-primary-dark">Create Custom Plan</Button>
            </div>
          </div>
        </motion.div>
      </TabsContent>
    </Tabs>
  )
}
