"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const data = [
  { day: "Mon", calories: 1950, weight: 70.2, steps: 8500 },
  { day: "Tue", calories: 2100, weight: 70.1, steps: 10200 },
  { day: "Wed", calories: 1850, weight: 70.0, steps: 7800 },
  { day: "Thu", calories: 2200, weight: 69.8, steps: 9300 },
  { day: "Fri", calories: 2050, weight: 69.7, steps: 11500 },
  { day: "Sat", calories: 2300, weight: 69.6, steps: 12800 },
  { day: "Sun", calories: 1900, weight: 69.5, steps: 6500 },
]

export function HealthMetricsChart() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="day" tick={{ fill: "#6b7280" }} />
        <YAxis yAxisId="left" tick={{ fill: "#6b7280" }} />
        <YAxis yAxisId="right" orientation="right" tick={{ fill: "#6b7280" }} />
        <Tooltip
          contentStyle={{
            backgroundColor: "white",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            border: "none",
          }}
        />
        <Legend />
        <Line
          yAxisId="left"
          type="monotone"
          dataKey="calories"
          stroke="#2ECC71"
          stroke
          type="monotone"
          dataKey="calories"
          stroke="#2ECC71"
          strokeWidth={2}
          activeDot={{ r: 8 }}
          name="Calories"
        />
        <Line yAxisId="right" type="monotone" dataKey="weight" stroke="#8E44AD" strokeWidth={2} name="Weight (kg)" />
        <Line yAxisId="left" type="monotone" dataKey="steps" stroke="#F39C12" strokeWidth={2} name="Steps" />
      </LineChart>
    </ResponsiveContainer>
  )
}
