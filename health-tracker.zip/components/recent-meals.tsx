"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash2 } from "lucide-react"
import { motion } from "framer-motion"

const meals = [
  {
    id: 1,
    name: "Greek Yogurt with Berries",
    time: "8:30 AM",
    calories: 180,
    protein: 15,
    carbs: 20,
    fat: 5,
    type: "Breakfast",
  },
  {
    id: 2,
    name: "Whole Grain Toast",
    time: "8:30 AM",
    calories: 160,
    protein: 6,
    carbs: 30,
    fat: 2,
    type: "Breakfast",
  },
  {
    id: 3,
    name: "Grilled Chicken Salad",
    time: "12:45 PM",
    calories: 320,
    protein: 35,
    carbs: 15,
    fat: 12,
    type: "Lunch",
  },
  {
    id: 4,
    name: "Apple",
    time: "3:30 PM",
    calories: 95,
    protein: 0.5,
    carbs: 25,
    fat: 0.3,
    type: "Snack",
  },
]

export function RecentMeals() {
  return (
    <div className="space-y-4">
      {meals.map((meal, index) => (
        <motion.div
          key={meal.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <div className="flex items-center justify-between p-4 border rounded-lg hover:border-primary transition-colors">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className="font-medium font-poppins">{meal.name}</h4>
                <Badge
                  variant="outline"
                  className={`text-xs ${
                    meal.type === "Breakfast"
                      ? "bg-primary/10 text-primary border-primary/30"
                      : meal.type === "Lunch"
                        ? "bg-orange/10 text-orange border-orange/30"
                        : meal.type === "Dinner"
                          ? "bg-accent/10 text-accent border-accent/30"
                          : "bg-teal/10 text-teal border-teal/30"
                  }`}
                >
                  {meal.type}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{meal.time}</p>
              <div className="flex gap-3 mt-1 text-xs">
                <span className="font-medium text-primary">{meal.calories} kcal</span>
                <span>P: {meal.protein}g</span>
                <span>C: {meal.carbs}g</span>
                <span>F: {meal.fat}g</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <Edit className="h-4 w-4" />
                <span className="sr-only">Edit</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-red-500">
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </div>
          </div>
        </motion.div>
      ))}
      <Button variant="outline" className="w-full border-dashed border-primary/50 text-primary hover:bg-primary/5">
        Add Meal
      </Button>
    </div>
  )
}
