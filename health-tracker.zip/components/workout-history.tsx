"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "lucide-react"

const workoutHistory = [
  {
    id: 1,
    date: "Today",
    workouts: [
      { name: "Morning Run", duration: 30, calories: 280, type: "Cardio" },
      { name: "Strength Training", duration: 45, calories: 320, type: "Strength" },
    ],
  },
  {
    id: 2,
    date: "Yesterday",
    workouts: [{ name: "Yoga Session", duration: 30, calories: 150, type: "Flexibility" }],
  },
  {
    id: 3,
    date: "Monday, Apr 11",
    workouts: [
      { name: "HIIT Workout", duration: 25, calories: 300, type: "Cardio" },
      { name: "Swimming", duration: 40, calories: 350, type: "Cardio" },
    ],
  },
  {
    id: 4,
    date: "Sunday, Apr 10",
    workouts: [{ name: "Rest Day", duration: 0, calories: 0, type: "Rest" }],
  },
]

export function WorkoutHistory() {
  return (
    <div className="space-y-6">
      {workoutHistory.map((day) => (
        <div key={day.id}>
          <div className="flex items-center mb-2">
            <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
            <h3 className="font-medium">{day.date}</h3>
          </div>
          <div className="space-y-2">
            {day.workouts.map((workout, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">{workout.name}</h4>
                    <Badge variant="outline" className="text-xs">
                      {workout.type}
                    </Badge>
                  </div>
                  <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
                    {workout.duration > 0 && <span>{workout.duration} min</span>}
                    {workout.calories > 0 && <span>{workout.calories} kcal</span>}
                  </div>
                </div>
                {workout.type !== "Rest" && (
                  <Button variant="ghost" size="sm">
                    Log Again
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
      <Button variant="outline" className="w-full">
        View More History
      </Button>
    </div>
  )
}
