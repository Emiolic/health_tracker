"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ExerciseEntryForm() {
  const [exerciseName, setExerciseName] = useState("")
  const [duration, setDuration] = useState("")
  const [exerciseType, setExerciseType] = useState("cardio")
  const [calories, setCalories] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log({ exerciseName, duration, exerciseType, calories })
    // Reset form
    setExerciseName("")
    setDuration("")
    setCalories("")
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="exercise-name">Exercise Name</Label>
        <Input
          id="exercise-name"
          placeholder="e.g., Running, Yoga"
          value={exerciseName}
          onChange={(e) => setExerciseName(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="exercise-type">Exercise Type</Label>
        <Select value={exerciseType} onValueChange={setExerciseType}>
          <SelectTrigger id="exercise-type">
            <SelectValue placeholder="Select exercise type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cardio">Cardio</SelectItem>
            <SelectItem value="strength">Strength</SelectItem>
            <SelectItem value="flexibility">Flexibility</SelectItem>
            <SelectItem value="balance">Balance</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="duration">Duration (minutes)</Label>
        <Input
          id="duration"
          type="number"
          placeholder="e.g., 30"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="calories">Calories Burned (estimated)</Label>
        <Input
          id="calories"
          type="number"
          placeholder="e.g., 250"
          value={calories}
          onChange={(e) => setCalories(e.target.value)}
        />
      </div>

      <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
        Log Exercise
      </Button>
    </form>
  )
}
