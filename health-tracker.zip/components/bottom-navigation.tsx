"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import { Activity, Apple, User, Mic, History } from "lucide-react"
import { Button } from "@/components/ui/button"

export function BottomNavigation() {
  const pathname = usePathname()
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)
  const [isRecording, setIsRecording] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false)
      } else {
        setIsVisible(true)
      }

      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  const handleMicClick = () => {
    setIsRecording(!isRecording)
    // Here you would implement actual voice recording functionality
  }

  const navItems = [
    { path: "/", icon: <Activity className="h-6 w-6" />, label: "Home" },
    { path: "/food", icon: <Apple className="h-6 w-6" />, label: "Food" },
    { path: "/meal-history", icon: <History className="h-6 w-6" />, label: "Meals" },
    { path: "/profile", icon: <User className="h-6 w-6" />, label: "Profile" },
  ]

  return (
    <motion.div
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden"
      initial={{ y: 0 }}
      animate={{ y: isVisible ? 0 : 100 }}
      transition={{ duration: 0.3 }}
    >
      <div className="bg-white border-t border-gray-200 shadow-lg rounded-t-xl">
        <div className="flex justify-around items-center h-16 relative">
          {navItems.slice(0, 2).map((item) => {
            const isActive = pathname === item.path

            return (
              <Link
                key={item.path}
                href={item.path}
                className="flex flex-col items-center justify-center w-full h-full relative"
              >
                <div
                  className={`flex flex-col items-center justify-center transition-all duration-300 ${
                    isActive ? "text-primary" : "text-gray-500"
                  }`}
                >
                  {item.icon}
                  <span className="text-xs mt-1 font-medium">{item.label}</span>

                  {isActive && (
                    <motion.div
                      className="absolute -bottom-0 w-12 h-1 bg-primary rounded-t-full"
                      layoutId="bottomNavIndicator"
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  )}
                </div>
              </Link>
            )
          })}

          {/* Center Mic Button */}
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
            <Button
              onClick={handleMicClick}
              className={`h-14 w-14 rounded-full shadow-lg flex items-center justify-center ${
                isRecording ? "bg-red-500 hover:bg-red-600" : "bg-accent hover:bg-accent-dark"
              }`}
            >
              <Mic className="h-6 w-6 text-white" />
            </Button>
          </div>

          {/* AI Coach Link - Middle position but visually hidden */}
          <Link href="/ai" className="flex flex-col items-center justify-center w-full h-full opacity-0">
            <div className="flex flex-col items-center justify-center">
              <span className="text-xs mt-1 font-medium">AI Coach</span>
            </div>
          </Link>

          {navItems.slice(2, 4).map((item) => {
            const isActive = pathname === item.path

            return (
              <Link
                key={item.path}
                href={item.path}
                className="flex flex-col items-center justify-center w-full h-full relative"
              >
                <div
                  className={`flex flex-col items-center justify-center transition-all duration-300 ${
                    isActive ? "text-primary" : "text-gray-500"
                  }`}
                >
                  {item.icon}
                  <span className="text-xs mt-1 font-medium">{item.label}</span>

                  {isActive && (
                    <motion.div
                      className="absolute -bottom-0 w-12 h-1 bg-primary rounded-t-full"
                      layoutId="bottomNavIndicator"
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  )}
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </motion.div>
  )
}
