"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Sparkles, User, Mic, ImageIcon, Paperclip } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

type Message = {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
}

const initialMessages: Message[] = [
  {
    id: "1",
    content: "Hello! I'm your AI health coach. How can I assist you with your health and wellness goals today?",
    sender: "ai",
    timestamp: new Date(Date.now() - 60000),
  },
]

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response after a delay
    setTimeout(() => {
      const aiResponses: { [key: string]: string } = {
        "how can i lose weight?":
          "To lose weight in a healthy way, focus on these key areas:\n\n1. Create a moderate calorie deficit (about 500 calories/day)\n2. Increase protein intake to preserve muscle mass\n3. Include strength training 2-3 times per week\n4. Stay hydrated and get adequate sleep\n5. Focus on whole foods rather than processed options\n\nWould you like me to create a personalized weight loss plan for you?",
        "what should i eat before a workout?":
          "For pre-workout nutrition, timing matters:\n\n• 2-3 hours before: A balanced meal with protein, complex carbs, and some healthy fats\n• 30-60 minutes before: A smaller snack focused on easily digestible carbs and some protein\n\nGood options include:\n- Banana with a tablespoon of peanut butter\n- Greek yogurt with berries\n- Oatmeal with protein powder\n- Rice cakes with a slice of turkey",
        "how much water should i drink?":
          "The general recommendation is to drink about 2.7 liters (91 ounces) daily for women and 3.7 liters (125 ounces) for men. However, your personal needs may vary based on:\n\n• Activity level\n• Climate\n• Body size\n• Health conditions\n\nA good rule of thumb is to drink enough so that your urine is pale yellow. Would you like me to help you calculate your specific hydration needs?",
        "i'm feeling tired all the time":
          "Persistent fatigue can have several causes:\n\n1. Poor sleep quality or insufficient sleep\n2. Nutrient deficiencies (especially iron, vitamin D, or B12)\n3. Dehydration\n4. Overtraining or lack of physical activity\n5. Stress or mental health issues\n\nBased on your health data, I notice your sleep patterns have been irregular. Would you like some strategies to improve your sleep quality?",
      }

      // Check if we have a canned response for this input
      const lowercaseInput = input.toLowerCase().trim()
      let responseText = ""

      for (const key in aiResponses) {
        if (lowercaseInput.includes(key)) {
          responseText = aiResponses[key]
          break
        }
      }

      // Default response if no match
      if (!responseText) {
        responseText =
          "That's a great question about your health. Based on your profile and health data, I'd recommend focusing on balanced nutrition and regular exercise. Would you like more specific guidance on this topic?"
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: responseText,
        sender: "ai",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`flex gap-3 max-w-[80%] ${message.sender === "user" ? "flex-row-reverse" : ""}`}>
                <div className="flex-shrink-0 mt-1">
                  {message.sender === "ai" ? (
                    <Avatar>
                      <AvatarFallback className="bg-accent text-white">AI</AvatarFallback>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    </Avatar>
                  ) : (
                    <Avatar>
                      <AvatarFallback className="bg-primary/20 text-primary">
                        <User className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
                <div>
                  <div
                    className={`p-3 rounded-lg ${message.sender === "user" ? "bg-primary text-white" : "bg-gray-100"}`}
                  >
                    <p className="whitespace-pre-line">{message.content}</p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{formatTimestamp(message.timestamp)}</p>
                </div>
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex justify-start">
              <div className="flex gap-3 max-w-[80%]">
                <div className="flex-shrink-0 mt-1">
                  <Avatar>
                    <AvatarFallback className="bg-accent text-white">AI</AvatarFallback>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                  </Avatar>
                </div>
                <div>
                  <div className="p-3 rounded-lg bg-gray-100">
                    <div className="flex space-x-2">
                      <div
                        className="w-2 h-2 rounded-full bg-accent/60 animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-accent/60 animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-accent/60 animate-bounce"
                        style={{ animationDelay: "600ms" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t p-4">
        <div className="flex gap-2">
          <Button variant="outline" size="icon" className="rounded-full">
            <Mic className="h-4 w-4 text-muted-foreground" />
          </Button>
          <Button variant="outline" size="icon" className="rounded-full">
            <ImageIcon className="h-4 w-4 text-muted-foreground" />
          </Button>
          <Button variant="outline" size="icon" className="rounded-full">
            <Paperclip className="h-4 w-4 text-muted-foreground" />
          </Button>
          <div className="relative flex-1">
            <Input
              placeholder="Ask your health coach anything..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="pr-10 rounded-full border-gray-300 focus-visible:ring-accent"
            />
            <Sparkles className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-accent" />
          </div>
          <Button
            onClick={handleSendMessage}
            size="icon"
            className="rounded-full bg-accent hover:bg-accent-dark"
            disabled={!input.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <div className="mt-2 text-xs text-center text-muted-foreground">
          AI responses are generated based on your health data and general health guidelines
        </div>
      </div>
    </div>
  )
}
