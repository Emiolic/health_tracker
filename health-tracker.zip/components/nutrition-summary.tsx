"use client"

export function NutritionSummary() {
  return (
    <div className="space-y-4">
      <div>
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium">Calories</span>
          <span className="text-sm font-medium">755 / 2,200</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "34%" }}></div>
        </div>
      </div>
      <div>
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium">Protein</span>
          <span className="text-sm font-medium">45g / 120g</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "38%" }}></div>
        </div>
      </div>
      <div>
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium">Carbs</span>
          <span className="text-sm font-medium">85g / 250g</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "34%" }}></div>
        </div>
      </div>
      <div>
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium">Fat</span>
          <span className="text-sm font-medium">25g / 70g</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: "36%" }}></div>
        </div>
      </div>
    </div>
  )
}
