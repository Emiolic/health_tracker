"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash2 } from "lucide-react"
import { motion } from "framer-motion"

const mealHistoryData = [
  {
    id: 1,
    date: "Today",
    meals: [
      { name: "Greek Yogurt with Berries", time: "8:30 AM", calories: 180, type: "Breakfast" },
      { name: "Grilled Chicken Salad", time: "12:45 PM", calories: 320, type: "Lunch" },
      { name: "Baked Salmon with Quinoa", time: "7:00 PM", calories: 420, type: "Dinner" },
      { name: "Apple with Almond Butter", time: "3:30 PM", calories: 170, type: "Snack" },
    ],
  },
  {
    id: 2,
    date: "Yesterday",
    meals: [
      { name: "Omelette", time: "9:00 AM", calories: 250, type: "Breakfast" },
      { name: "Turkey Sandwich", time: "1:00 PM", calories: 350, type: "Lunch" },
      { name: "Vegetable Stir Fry", time: "6:30 PM", calories: 380, type: "Dinner" },
      { name: "Greek Yogurt", time: "4:00 PM", calories: 120, type: "Snack" },
    ],
  },
  {
    id: 3,
    date: "Monday, Apr 14",
    meals: [
      { name: "Avocado Toast", time: "8:15 AM", calories: 280, type: "Breakfast" },
      { name: "Quinoa Bowl", time: "12:30 PM", calories: 390, type: "Lunch" },
      { name: "Grilled Chicken with Vegetables", time: "7:15 PM", calories: 410, type: "Dinner" },
      { name: "Protein Shake", time: "3:00 PM", calories: 150, type: "Snack" },
    ],
  },
]

interface MealHistoryProps {
  mealType?: string
}

export function MealHistory({ mealType }: MealHistoryProps) {
  // Filter meals based on mealType if provided
  const filteredData = mealHistoryData
    .map((day) => ({
      ...day,
      meals: mealType ? day.meals.filter((meal) => meal.type === mealType) : day.meals,
    }))
    .filter((day) => day.meals.length > 0)

  return (
    <div className="space-y-6">
      {filteredData.map((day) => (
        <div key={day.id}>
          <h3 className="font-medium mb-2 font-poppins">{day.date}</h3>
          <div className="space-y-2">
            {day.meals.map((meal, index) => (
              <motion.div
                key={`${meal.name}-${meal.time}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <div className="flex items-center justify-between p-3 border rounded-lg hover:border-primary transition-colors">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium font-poppins">{meal.name}</h4>
                      <Badge
                        variant="outline"
                        className={`text-xs ${
                          meal.type === "Breakfast"
                            ? "bg-primary/10 text-primary border-primary/30"
                            : meal.type === "Lunch"
                              ? "bg-orange/10 text-orange border-orange/30"
                              : meal.type === "Dinner"
                                ? "bg-accent/10 text-accent border-accent/30"
                                : "bg-teal/10 text-teal border-teal/30"
                        }`}
                      >
                        {meal.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{meal.time}</p>
                    <p className="text-xs text-primary font-medium mt-1">{meal.calories} calories</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                      <Edit className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-red-500">
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      ))}
      <Button variant="outline" className="w-full">
        View More History
      </Button>
    </div>
  )
}
