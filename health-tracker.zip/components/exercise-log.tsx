"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash2 } from "lucide-react"
import { motion } from "framer-motion"

const exercises = [
  {
    id: 1,
    name: "Morning Run",
    time: "7:30 AM",
    duration: 30,
    calories: 280,
    type: "Cardio",
  },
  {
    id: 2,
    name: "Strength Training",
    time: "6:00 PM",
    duration: 45,
    calories: 320,
    type: "Strength",
  },
  {
    id: 3,
    name: "Yoga Session",
    time: "8:00 PM",
    duration: 30,
    calories: 150,
    type: "Flexibility",
  },
]

export function ExerciseLog() {
  return (
    <div className="space-y-4">
      {exercises.map((exercise, index) => (
        <motion.div
          key={exercise.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <div className="flex items-center justify-between p-4 border rounded-lg hover:border-orange transition-colors">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className="font-medium font-poppins">{exercise.name}</h4>
                <Badge
                  variant="outline"
                  className={`text-xs ${
                    exercise.type === "Cardio"
                      ? "bg-orange/10 text-orange border-orange/30"
                      : exercise.type === "Strength"
                        ? "bg-primary/10 text-primary border-primary/30"
                        : "bg-teal/10 text-teal border-teal/30"
                  }`}
                >
                  {exercise.type}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{exercise.time}</p>
              <div className="flex gap-3 mt-1 text-xs">
                <span className="font-medium text-orange">{exercise.duration} min</span>
                <span>{exercise.calories} kcal</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-orange">
                <Edit className="h-4 w-4" />
                <span className="sr-only">Edit</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-red-500">
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </div>
          </div>
        </motion.div>
      ))}
      <Button variant="outline" className="w-full border-dashed border-orange/50 text-orange hover:bg-orange/5">
        Add Exercise
      </Button>
    </div>
  )
}
